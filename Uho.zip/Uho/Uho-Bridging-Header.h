//
//  XYPieChart-Bridging-Header.h
//  Uho
//
//  Created by Bharath Booshan on 3/26/16.
//  Copyright © 2016 Feather Touch. All rights reserved.
//

#ifndef XYPieChart_Bridging_Header_h
#define XYPieChart_Bridging_Header_h

#import "XYPieChart.h"

#endif /* XYPieChart_Bridging_Header_h */
