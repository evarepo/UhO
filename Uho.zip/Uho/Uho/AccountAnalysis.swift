//
//  AccountAnalysis.swift
//  Uho
//
//  Created by Bharath Booshan on 3/27/16.
//  Copyright © 2016 Feather Touch. All rights reserved.
//

import Foundation

class AccountAnalysis {
    
    
    
    
    init(){
        
    }
    
    
    
    
}