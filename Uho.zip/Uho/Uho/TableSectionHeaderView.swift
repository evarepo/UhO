//
//  TableSectionHeaderView.swift
//  Uho
//
//  Created by Bharath Booshan on 4/4/16.
//  Copyright © 2016 Feather Touch. All rights reserved.
//

import Foundation

class TableSectionHeaderView : UITableViewHeaderFooterView {
    
    @IBOutlet weak var titleLabel : UILabel?
    
}