//
//  UserDetails.swift
//  Uho
//
//  Created by Pawan Jat on 07/04/16.
//  Copyright © 2016 Feather Touch. All rights reserved.
//

import Foundation

class UserDetails {
 
    var userInfo:NSDictionary?
    var userAnalysis:NSDictionary?
//    var userInfo: User?

   
//    init(data: NSDictionary!) {
//        
//    }
//    func dictionaryRepresentation() -> Dictionary<String,AnyObject>? {
//        var dictRep = Dictionary<String,AnyObject>()
////        dictRep["analysis"] = userInfo
//        dictRep["user"] = userAnalysis
//        return dictRep
//    }
   
}